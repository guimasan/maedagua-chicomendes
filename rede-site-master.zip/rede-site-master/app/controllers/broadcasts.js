exports.connect = function(req, res){
  console.log('conecta');
  res.send('eita');
}
